# hstapcorr
hstapcorr is a python package containing tables for aperture correction with HST instruments including HST/ACS/WFC and HST/WFC3/IR and UVIS for both imaging (photapcorr.py) and grism (grismapcorr.py).
